const Razorpay = require('razorpay');
const crypto = require('crypto');
const Payment = require('../models/Payment');

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Create Razorpay Order
const createRazorpayOrder = async (amount, currency = 'INR') => {
  const razorpayOrder = await razorpay.orders.create({
    amount: amount * 100, // Convert to paise
    currency,
    receipt: `receipt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  });
  return razorpayOrder;
};

// Verify Payment Signature
const verifyPaymentSignature = (orderId, paymentId, signature) => {
  const sign = orderId + '|' + paymentId;
  const expectedSign = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(sign.toString())
    .digest('hex');
  return expectedSign === signature;
};

module.exports = { 
  createRazorpayOrder, 
  verifyPaymentSignature 
};
