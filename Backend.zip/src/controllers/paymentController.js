const Payment = require('../models/Payment');
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const { createRazorpayOrder, verifyPaymentSignature } = require('../services/paymentService');

class PaymentController {
  
  // 1. Create Payment Order (From Cart)
  static async createPayment(req, res, next) {
    try {
      const cart = await Cart.findOne({ user: req.user.userId }).populate('items.product');
      
      if (!cart || cart.items.length === 0) {
        return res.status(400).json({ 
          success: false, 
          message: 'Cart is empty' 
        });
      }

      // Create Razorpay order
      const razorpayOrder = await createRazorpayOrder(cart.totalAmount);
      
      // Save payment record
      const payment = new Payment({
        user: req.user.userId,
        orderId: null, // Will be created after payment
        razorpayOrderId: razorpayOrder.id,
        amount: cart.totalAmount,
        status: 'created'
      });
      await payment.save();

      res.json({
        success: true,
        payment: {
          id: payment._id,
          razorpayOrderId: razorpayOrder.id,
          amount: razorpayOrder.amount / 100,
          currency: razorpayOrder.currency,
          key: process.env.RAZORPAY_KEY_ID,
          name: 'Fashion Basket'
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // 2. Verify Payment & Create Order
  static async verifyPayment(req, res, next) {
    try {
      const { razorpayOrderId, razorpayPaymentId, razorpaySignature } = req.body;
      
      // Verify signature
      const isValidSignature = verifyPaymentSignature(
        razorpayOrderId, 
        razorpayPaymentId, 
        razorpaySignature
      );
      
      if (!isValidSignature) {
        return res.status(400).json({ 
          success: false, 
          message: 'Invalid payment signature' 
        });
      }

      // Update payment status
      const payment = await Payment.findOne({ razorpayOrderId });
      if (!payment) {
        return res.status(400).json({ message: 'Payment not found' });
      }

      payment.razorpayPaymentId = razorpayPaymentId;
      payment.razorpaySignature = razorpaySignature;
      payment.status = 'paid';
      await payment.save();

      // Get cart and create order
      const cart = await Cart.findOne({ user: req.user.userId }).populate('items.product');
      const order = new Order({
        user: req.user.userId,
        items: cart.items,
        totalAmount: cart.totalAmount,
        paymentId: payment._id,
        status: 'confirmed',
        shippingAddress: req.body.shippingAddress || {}
      });
      await order.save();

      // Clear cart
      await Cart.findOneAndUpdate({ user: req.user.userId }, { 
        items: [], 
        totalAmount: 0 
      });

      res.json({
        success: true,
        message: 'Payment successful! Order created.',
        order: {
          id: order._id,
          orderId: order._id,
          amount: order.totalAmount,
          status: order.status
        }
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = PaymentController;
