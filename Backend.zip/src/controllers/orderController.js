const Order = require('../models/Order');
const Cart = require('../models/Cart');

// 1. Create Order (Line 7 માં આ function જોઈએ!)
const createOrder = async (req, res, next) => {
  try {
    const { paymentId } = req.body;
    
    // Get cart
    const cart = await Cart.findOne({ user: req.user.userId }).populate('items.product');
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Cart is empty' 
      });
    }
    
    // Create order from cart
    const order = new Order({
      user: req.user.userId,
      items: cart.items,
      totalAmount: cart.totalAmount,
      paymentId: paymentId || null,
      status: 'confirmed',
      shippingAddress: req.body.shippingAddress || {}
    });
    
    await order.save();
    
    // Clear cart after order
    await Cart.findOneAndUpdate(
      { user: req.user.userId }, 
      { items: [], totalAmount: 0 }
    );
    
    res.status(201).json({ 
      success: true, 
      message: 'Order created successfully!',
      order 
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get User Orders
const getOrders = async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.user.userId })
      .populate('items.product')
      .sort({ createdAt: -1 });
    
    res.json({ 
      success: true, 
      orders 
    });
  } catch (error) {
    next(error);
  }
};

// 3. Get Single Order
const getOrder = async (req, res, next) => {
  try {
    const order = await Order.findOne({ 
      _id: req.params.id, 
      user: req.user.userId 
    }).populate('items.product');
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    res.json({ 
      success: true, 
      order 
    });
  } catch (error) {
    next(error);
  }
};

// ✅ EXPORT ALL FUNCTIONS
module.exports = { 
  createOrder, 
  getOrders, 
  getOrder 
};
