const Cart = require('../models/Cart');
const Product = require('../models/Product');

// 1. Add to Cart (Line 7 માં આ function જોઈએ)
const addToCart = async (req, res, next) => {
  try {
    const { productId, quantity = 1, size, color } = req.body;
    
    // Find or create cart
    let cart = await Cart.findOne({ user: req.user.userId });
    if (!cart) {
      cart = new Cart({ user: req.user.userId, items: [] });
    }
    
    // Check product exists & stock
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    
    // Check if item already exists
    const itemIndex = cart.items.findIndex(item => 
      item.product.toString() === productId && 
      item.size === size
    );
    
    if (itemIndex > -1) {
      // Update quantity
      cart.items[itemIndex].quantity += quantity;
    } else {
      // Add new item
      cart.items.push({ 
        product: productId, 
        quantity, 
        size, 
        color,
        price: product.price 
      });
    }
    
    // Calculate total
    cart.totalAmount = cart.items.reduce((sum, item) => {
      const productPrice = item.price || product.price;
      return sum + (item.quantity * productPrice);
    }, 0);
    
    await cart.save();
    await cart.populate('items.product');
    
    res.json({ 
      success: true, 
      message: 'Item added to cart', 
      cart 
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get Cart
const getCart = async (req, res, next) => {
  try {
    const cart = await Cart.findOne({ user: req.user.userId })
      .populate('items.product');
    
    res.json({ 
      success: true, 
      cart: cart || { items: [], totalAmount: 0 } 
    });
  } catch (error) {
    next(error);
  }
};

// 3. Remove from Cart
const removeFromCart = async (req, res, next) => {
  try {
    const cart = await Cart.findOne({ user: req.user.userId });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });
    
    cart.items = cart.items.filter(item => 
      item._id.toString() !== req.params.itemId
    );
    
    cart.totalAmount = cart.items.reduce((sum, item) => 
      sum + (item.quantity * item.price), 0
    );
    
    await cart.save();
    res.json({ success: true, cart });
  } catch (error) {
    next(error);
  }
};

// 4. Update Cart Item
const updateCart = async (req, res, next) => {
  try {
    const { quantity } = req.body;
    const cart = await Cart.findOne({ user: req.user.userId });
    
    const itemIndex = cart.items.findIndex(item => 
      item._id.toString() === req.params.itemId
    );
    
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity = quantity;
      cart.totalAmount = cart.items.reduce((sum, item) => 
        sum + (item.quantity * item.price), 0
      );
      await cart.save();
      res.json({ success: true, cart });
    } else {
      res.status(404).json({ message: 'Item not found' });
    }
  } catch (error) {
    next(error);
  }
};

// ✅ EXPORT ALL FUNCTIONS
module.exports = { 
  addToCart, 
  getCart, 
  removeFromCart, 
  updateCart 
};
