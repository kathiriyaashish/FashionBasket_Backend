const User = require('../models/User');
const OTP = require('../models/OTP');
const jwt = require('jsonwebtoken');
const { sendOTP } = require('../services/emailService');

// Generate 6 digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// 1. Send OTP to email
const sendLoginOTP = async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    const otp = generateOTP();
    
    // Save OTP (5 min auto-expiry)
    await OTP.findOneAndUpdate(
      { email },
      { email, otp, createdAt: new Date() },
      { upsert: true, new: true }
    );
    
    await sendOTP(email, otp);
    
    res.json({ 
      message: '✅ OTP sent to your email! Check inbox/spam.',
      success: true 
    });
    
  } catch (error) {
    res.status(500).json({ message: 'Failed to send OTP' });
  }
};

// 2. Verify OTP + DELETE OTP + Auto Login/Register
const verifyOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;
    
    if (!email || !otp) {
      return res.status(400).json({ message: 'Email and OTP required' });
    }
    
    // ✅ Check & Verify OTP
    const otpRecord = await OTP.findOne({ email, otp });
    if (!otpRecord) {
      return res.status(400).json({ message: '❌ Invalid or expired OTP' });
    }
    
    // ✅ DELETE OTP after successful verification
    await OTP.deleteOne({ email });
    console.log(`✅ OTP deleted for ${email}`);
    
    // Check/Create user
    let user = await User.findOne({ email });
    if (!user) {
      user = new User({ 
        email, 
        name: email.split('@')[0],
        isVerified: true 
      });
      await user.save();
    }
    
    // Generate JWT
    const token = jwt.sign(
      { userId: user._id }, 
      process.env.JWT_SECRET, 
      { expiresIn: '7d' }
    );
    
    res.json({ 
      message: '🎉 Login successful! OTP deleted.',
      success: true,
      token,
      user: { id: user._id, email: user.email, name: user.name }
    });
    
  } catch (error) {
    res.status(500).json({ message: 'Login failed' });
  }
};

// 3. Get Profile
const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ message: 'Profile fetch failed' });
  }
};

module.exports = { sendLoginOTP, verifyOTP, getProfile };
