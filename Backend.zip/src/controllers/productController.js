const Product = require('../models/Product');
const Category = require('../models/Category');

// 1. Get all products (Line 8 માં આ function જોઈએ)
const getProducts = async (req, res, next) => {
  try {
    const { category, size, search, page = 1, limit = 12 } = req.query;
    const query = {};
    
    if (category) query.category = category;
    if (search) query.name = { $regex: search, $options: 'i' };
    
    const products = await Product.find(query)
      .populate('category')
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await Product.countDocuments(query);
    
    res.json({ 
      success: true,
      products, 
      total, 
      pages: Math.ceil(total / limit) 
    });
  } catch (error) {
    next(error);
  }
};

// 2. Get single product
const getProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id).populate('category');
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    res.json({ success: true, product });
  } catch (error) {
    next(error);
  }
};

// 3. Create product
const createProduct = async (req, res, next) => {
  try {
    const productData = { ...req.body };
    
    // Add image URL if uploaded
    if (req.imageUrl) {
      productData.images = [req.imageUrl];
    }
    
    const product = new Product(productData);
    await product.save();
    
    res.status(201).json({ success: true, product });
  } catch (error) {
    next(error);
  }
};

// ✅ EXPORT ALL FUNCTIONS (આ missing હતું!)
module.exports = { 
  getProducts, 
  getProduct, 
  createProduct 
};
