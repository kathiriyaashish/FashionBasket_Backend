const express = require('express');
const { sendLoginOTP, verifyOTP, getProfile } = require('../controllers/authController');
const authMiddleware = require('../middlewares/auth');
const router = express.Router();

router.post('/send-otp', sendLoginOTP);
router.post('/verify-otp', verifyOTP);
router.get('/profile', authMiddleware, getProfile);

module.exports = router;
