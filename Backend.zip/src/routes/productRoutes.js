const express = require('express');
const { getProducts, getProduct, createProduct } = require('../controllers/productController');
const authMiddleware = require('../middlewares/auth');
const { uploadImage } = require('../services/cloudinary');
const router = express.Router();

router.get('/', getProducts);
router.get('/:id', getProduct);
router.post('/', authMiddleware, uploadImage, createProduct);

module.exports = router;
