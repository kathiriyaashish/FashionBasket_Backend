const express = require('express');
const authMiddleware = require('../middlewares/auth');
const { createOrder, getOrders, getOrder } = require('../controllers/orderController');
const router = express.Router();

router.use(authMiddleware);
router.post('/', createOrder);
router.get('/', getOrders);
router.get('/:id', getOrder);

module.exports = router;
