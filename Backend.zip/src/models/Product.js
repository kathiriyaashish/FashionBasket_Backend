const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  price: { type: Number, required: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  images: [String],
  stock: { type: Number, default: 0, min: 0 },
  size: [{ type: String, enum: ['S', 'M', 'L', 'XL', 'XXL'] }],
  color: [String],
  isFeatured: { type: Boolean, default: false },
  discount: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Product', productSchema);
